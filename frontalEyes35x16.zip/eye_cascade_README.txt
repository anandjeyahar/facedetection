This cascade is trained for detection of frontal views of eyes.
Original object size = (35, 16)